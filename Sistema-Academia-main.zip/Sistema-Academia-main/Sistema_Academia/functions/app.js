function trocarListaUsuarios() {
    document.getElementById("telaPrincipal").src="listaUsuarios.php";
}

function trocarFinanceiro() {
    document.getElementById("telaPrincipal").src="financeiro.php";
}

function trocarMaquinas() {
    document.getElementById("telaPrincipal").src="../pages/maquinas.php";
}

